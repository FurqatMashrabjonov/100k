<?php

namespace App\Observers;

use App\Models\Checkout;
use App\Models\Discount;
use App\Models\Product;

class CheckoutObserver
{
//    public function creating(Checkout $checkout){
//
//    }
}
