<?php


namespace App\Http\Controllers\Admin;


use App\Models\Discount;
use App\Models\Image;
use App\Models\Product;
use http\Env\Response;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class ProductsController
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View|\Illuminate\Http\Response
     */
    public function index()
    {
        $products = Product::query()->with(['status', 'type', 'image', 'discount'])->get();
        return view('admin.products', compact('products'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Http\JsonResponse|\Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => ['required'],
            'description' => ['required'],
            'type_id' => ['required', 'numeric', 'exists:types,id'],
            'price' => ['required', 'numeric'],
            'images' => ['required', 'mimes:jpg,jpeg,png'],
            'count' => ['required', 'numeric'],
            'discount_id' => ['numeric']
        ]);

        $product = new Product();
        $product->name = $request->name;
        $product->description = $request->description;
        $product->price = $request->price;
        $product->type_id = $request->type_id;
        $product->status_id = Product::NOT_SALED;
        $product->token = Str::random(40);
        $product->user_id = auth()->user()->getAuthIdentifier();
        $product->like = 0;

        $discount = Discount::find($request->discount_id);
        if (!empty($discount) and $discount)
            $product->discount_id = $request->discount_id;
        else
            $product->discount_id = 0;
        $product->count = $request->count;

        if ($product->save()) {

            $image = $request->file('images');
            $image_name = time() . '.' . $image->getClientOriginalName();
            $destinationPath = public_path('products');
            $image->move($destinationPath, $image_name);
            Image::query()->insert([
                'name' => $image_name,
                'product_id' => $product->id
            ]);
            //
//            foreach ($images as $image) {
//                $image_name = time() . '.' . $image->getClientOriginalName();
//                $destinationPath = public_path('products');
//                $image->move($destinationPath, $image_name);
//                Image::query()->insert([
//                    'name' => $image_name,
//                    'product_id' => $product->id
//                ]);
//            }

        }
        return redirect("admin/products");
    }

    /**
     * Display the specified resource.
     *
     * @param \App\Models\Product $product
     * @return \Illuminate\Http\Response
     */
    public function show(Product $product)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param \App\Models\Product $product
     * @return \Illuminate\Http\Response
     */
    public function edit(Product $product)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param \App\Models\Product $product
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(Request $request)
    {
        $res = Product::query()
            ->where("id", $request->product_id)
            ->update($request->all(['name', 'price', 'count', 'pay']));
        if ($res)
            return redirect()->back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param \App\Models\Product $product
     * @return \Illuminate\Http\Response
     */
    public function destroy(Product $product)
    {
        //
    }
}
