<?php $__env->startSection("content"); ?>

    <div class="container m-auto">

        <?php echo $__env->make("components.admin_menu", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <br>
        <br>
        <?php if(count($payments) !== 0): ?>
            <table class="uk-table  uk-table-divider">
                <thead>

                <tr>
                    <th>Karta raqami</th>
                    <th>Summa</th>
                    <th>Yaratilgan sana</th>
                    <th>Qabul qilingan sana</th>
                    <th>Status</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr style="background-color: <?php if ($payment->status_one->id === \App\Models\Payment::PAYED) echo "aquamarine";  ?>">
                    <td><?php echo e(FormatCreditCard($payment->card_number)); ?></td>
                    <td><?php echo e(price_format($payment->amount)); ?></td>
                    <td><?php echo e($payment->created_at); ?></td>
                    <td><?php echo e(($payment->created_at !== $payment->updated_at) ? $payment->updated_at : "Hali qabul qilinmadi"); ?></td>
                    <td><?php echo e($payment->status_one->description); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
    <?php else: ?>
            <div uk-alert>
                <a class="uk-alert-close" ></a>
                <h3>Balans tarixi bo'sh</h3>

            </div>
    <?php endif; ?>


<?php $__env->stopSection(); ?>


<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/u1382474/baraka-shop.uz/resources/views/profile/balance_history.blade.php ENDPATH**/ ?>