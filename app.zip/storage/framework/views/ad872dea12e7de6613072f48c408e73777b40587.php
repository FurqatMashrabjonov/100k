

<?php $__env->startSection("content"); ?>

    <div class="container m-auto">

        <h1 class="lg:text-2xl text-lg font-extrabold leading-none text-gray-900 tracking-tight mb-2"> Mening
            Sevimlilarim</h1>

        <div class="relative mt-4">

            <div class="uk-slider-container pb-3">
                <?php if(count($likes) !== 0): ?>
                    <div class="list_products uk-child-width-1-5@m uk-child-width-1-3@s uk-child-width-1-2 uk-grid-small uk-grid">
                        <?php $__currentLoopData = $likes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $like): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div>
                                <a href="<?php echo e(url("product/" . $like->product->id)); ?>"
                                   uk-toggle="target: #offcanvas-preview">
                                    <div class="market-list">
                                        <div class="item-media"><img src="<?php echo e(pImgUrl($like->product)); ?>" alt="" uk-img>
                                        </div>

                                        <div class="item-inner">
                                            <div class="item-price"> <?php echo e(price_format($like->product->price)); ?></div>
                                            <div class="item-title"> <?php echo e(substr($like->product->name, 0, 20)); ?>...</div>
                                            <div class="item-statistic">
                                                <span> <span class="count"><?php echo e($like->product->like); ?></span> likes </span>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php else: ?>
                    <div uk-alert>
                        <a class="uk-alert-close" uk-close></a>
                        <h3>Sizning sevimli tovarlaringiz mavjud emas!</h3>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/u1382474/baraka-shop.uz/resources/views/profile/likes.blade.php ENDPATH**/ ?>