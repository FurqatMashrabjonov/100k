

<?php $__env->startSection('content'); ?>

    <div class="container m-auto">

        <?php echo $__env->make("components.admin_menu", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <br><br><br>
        <div class="lg:flex justify-center lg:space-x-10 lg:space-y-0 space-y-5">

            <div class="uk-alert-success" uk-alert>
                <a class="uk-alert-close"></a>
                <p style="color: cornflowerblue"><strong>Mening referal linkim:</strong>   <?php echo e($team_url); ?>

                </p>

            </div>
            <br><br>
        </div>
        <div>
            <div class="lg:flex justify-center lg:space-x-10 lg:space-y-0 space-y-5">
                <?php if(count($my_teams) !== 0): ?>
                    <table class="uk-table  uk-table-divider">
                        <thead>
                        <tr>
                            <th>ID</th>
                            <th>FIO</th>
                            <th>Telefon raqami</th>
                            <th>Sana</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $my_teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $my_team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($my_team->id); ?></td>
                                <td><?php echo e($my_team->user->full_name); ?></td>
                                <td><?php echo e(phone_format($my_team->user->phone)); ?></td>
                                <td><?php echo e($my_team->created_at); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div uk-alert>
                        <a class="uk-alert-close" ></a>
                        <h3>Sizda jamoa a'zolari mavjud emas</h3>

                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>


    <script src="<?php echo e(asset('assets/js/jquery-3.3.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset("assets/js/jquery.mask.js")); ?>"></script>

    <script>
        $("#card_number1").focusout(function () {
            $("#card_number").val($("#card_number1").val().match(/\d/g).join(""))
        })

        $("#card_number1").mask("0000 0000 0000 0000");
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/u1382474/baraka-shop.uz/resources/views/profile/team.blade.php ENDPATH**/ ?>