<?php $__env->startSection("content"); ?>

   Aloqa uchun

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/u1382474/baraka-shop.uz/resources/views/contact.blade.php ENDPATH**/ ?>