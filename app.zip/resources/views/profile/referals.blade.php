@extends("layouts.app")

@section("content")

    <div class="container m-auto">

        @include("components.admin_menu")
        <div class="uk-child-width-1-3@m uk-child-width-1-3@s uk-child-width-1-2 uk-grid-small uk-grid" uk-grid>
            @if(count($referals) !== 0)
                @foreach($referals as $referal)
                    <div>
                        <div class="uk-card uk-card-default uk-card-body" style="margin-top: 3em; padding: 20px !important; border-radius: 15px">

                            <p>{{(isset($referal->name) ? $referal->name : 'No name')}}</p>
                            <div class="flex" style="justify-content: start; align-items: center;">
                            <p style="font-weight: 900;"> {{$referal->view}}</p>
                                <img src="{{asset("icons/view.png")}}" alt="" width="20px" style="margin-left: 5px">
                            </div>
                            <textarea class="token_input" type="text" disabled style="padding: 5px; margin-top: 5px"
                                      value="">{{referalUrlMaker($referal->token)}}</textarea>
                            <br>
                            <div class="flex" style="justify-content: space-between; align-items: center;">
                                <button type="button" class="token_button uk-button uk-button-primary" style="width: 75% ; margin-right: 5px">Nusxa olish
                                </button>
                                <a href="{{url("profile/admin/referals/delete/" . $referal->id)}}"
                                   class=" uk-button-danger" style="display: flex; justify-content: center; align-items: center; padding: 5px; border-radius: 5px">
                                    <ion-icon name="trash-outline" ></ion-icon></a>
                            </div>

                        </div>
                    </div>
                @endforeach
            @else
                <div uk-alert>
                    <a class="uk-alert-close"></a>
                    <h3>Sizda oqimlar mavjud emas</h3>
                    <p>Oqim yaratish uchun <a href="{{url("profile/admin/market")}}" style="color: #0e6dcd">ushbu</a>
                        havola orqali oqimlar
                        bo'limiga o'ting!</p>
                </div>
            @endif
        </div>

        <script src="{{asset('assets/js/jquery-3.3.1.min.js')}}"></script>
        <script>

            $(".token_button").on('click', function () {
                const txt = document.createElement('textarea');
                document.body.appendChild(txt);
                txt.value = $(".token_input").text(); // chrome uses this
                txt.textContent = 'from textContent'; // FF uses this
                var sel = getSelection();
                var range = document.createRange();
                range.selectNode(txt);
                sel.removeAllRanges();
                sel.addRange(range);
                if (document.execCommand('copy')) {
                    $(this).text("Nusxa olindi")
                }
                document.body.removeChild(txt);
            });

        </script>

@endsection
