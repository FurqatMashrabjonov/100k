@extends("layouts.app")
@section("content")

    <div class="container m-auto">

        @include("components.admin_menu")
        <br>
        <br>
        @if(count($referals) !== 0)
            <table class="uk-table  uk-table-divider">
                <thead>
                <tr>
                    <th>Oqim</th>
                    <th>Ko'rildi</th>
                    <th>Qabul qilindi</th>
                    <th>Yetkazilmoqda</th>
                    <th>Yetqazib berildi</th>
                    <th>Bekor qilindi</th>
                </tr>
                </thead>
                <tbody>
                @foreach($referals as $referal)
                <tr>
                    <td>{{(strlen($referal['name']) >10) ? explode($referal['name'], 10) : $referal['name']}}</td>
                    <td>{{$referal['view']}}</td>
                    <td>{{$referal['not_saled']}}</td>
                    <td>{{$referal['deliving']}}</td>
                    <td>{{$referal['saled']}}</td>
                    <td>{{$referal['ignore']}}</td>
                </tr>
                @endforeach
                </tbody>
            </table>
    @else
            <div uk-alert>
                <a class="uk-alert-close" ></a>
                <h3>Sizda statistika mavjud emas</h3>

            </div>
    @endif


@endsection

