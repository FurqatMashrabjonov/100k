@extends("layouts.app")

@section("content")

    Favorites

@endsection
