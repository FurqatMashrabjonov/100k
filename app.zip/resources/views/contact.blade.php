@extends("layouts.app")

@section("content")

   Aloqa uchun

@endsection
