<?php

return [
    'api_url' => env('SMS_URL', 'http://sms.etc.uz:8084'),
    'login' => env('SMS_LOGIN', 'sms0017ts'),
    'password' => env('SMS_PASSWORD', 'qaz1234'),
    'cgpn' => env('CGPN', 1490)
];
