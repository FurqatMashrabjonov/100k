<?php $__env->startSection('content'); ?>
    <div class="content_auth" style="background-image: url( <?php echo e(asset("assets/img/back-blur.jpg")); ?>)">




        <div class="content_auth_block">
            <div id="authContainer">


                <form action="<?php echo e(route("verify")); ?>" method="post" class="content_auth_form">


                    <?php if(isset($token_error)): ?>
                        <span class="alert alert-danger"><?php echo e($token_error); ?></span>
                    <?php endif; ?>


                    <?php echo csrf_field(); ?>
                    <a href="<?php echo e(url('/')); ?>" class="header_navbar_brand_logo">100k.uz </a>
                    <label class="content_auth_form_group">
                        <span>Verify </span>

                        <div class="content_auth_form_group_input">
                            <input
                                name="phone_token"
                                type="text"
                                class="form-control my-phone-mask"
                                id="phone_token"
                                placeholder="Kodni kiriting"
                            />

                            <button type="submit" class="btn">
                                <i class="far fa-arrow-alt-circle-right"></i>
                            </button>
                        </div>
                    </label>
                        <a href="<?php echo e(url("verify")); ?>">Qayta Yuborish</a>
                </form>
            </div>
        </div>

    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServer8\OpenServer\domains\100\100k\resources\views/auth/verify.blade.php ENDPATH**/ ?>