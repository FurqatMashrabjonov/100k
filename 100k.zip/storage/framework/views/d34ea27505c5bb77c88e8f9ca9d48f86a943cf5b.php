<?php $__env->startSection("content"); ?>


    <h1>Profile</h1>


<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServer8\OpenServer\domains\100\100k\resources\views/profile/index.blade.php ENDPATH**/ ?>