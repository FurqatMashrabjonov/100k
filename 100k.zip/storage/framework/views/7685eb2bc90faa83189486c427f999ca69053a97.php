<?php $__env->startSection('content'); ?>








































































<div class="content_auth" style="background-image: url( <?php echo e(asset("assets/img/back-blur.jpg")); ?>)">




    <div class="content_auth_block">
        <div id="authContainer">
            <form action="<?php echo e(route("before_login")); ?>" method="post" class="content_auth_form">
                <?php echo csrf_field(); ?>
                <a href="<?php echo e(url('/')); ?>" class="header_navbar_brand_logo">100k.uz </a>
                <label class="content_auth_form_group">
                    <span> Войти в систему </span>

                    <div class="content_auth_form_group_input">
                        <input
                            type="phone"
                            class="form-control my-phone-mask"
                            id="phone1"
                            placeholder="Telefon raqamningizni kiriting"
                        />
                        <input type="hidden" style="display: none" id="phone" name="phone" >

                        <button type="submit" class="btn">
                            <i class="far fa-arrow-alt-circle-right"></i>
                        </button>
                    </div>
                    <p class="mt-2"> <label> <input type="checkbox" required> Men qoidalar bilan tanishdim <a class="terms text-danger" target="_blank" href="pages/privacy-policy.html"> Условия использования </a>  </label> </p>
                </label>
            </form>
        </div>
    </div>

</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection("scripts"); ?>
    <script src="<?php echo e(asset("assets/js/jquery.mask.js")); ?>"></script>
    <script>
        $(document).ready(function($){
            $("#phone1").mask("(99) 000 00 00");

            $("#phone1").focusout(function (){
                if ($("#phone1").val().length > 0)
                $("#phone").val($("#phone1").val().match(/\d/g).join(""))
                console.log( $("#phone").val())
            })

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServer8\OpenServer\domains\100\100k\resources\views/auth/login.blade.php ENDPATH**/ ?>