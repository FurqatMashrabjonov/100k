<?php $__env->startSection('content'); ?>


    <div class="container">
        <br>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="post" action="<?php echo e(url()->current()); ?>" enctype="multipart/form-data" class="content_profile">
            <?php echo csrf_field(); ?>
            <div class="content_profile_main">
                <div class="content_profile_name">
                    <div class="preview_avatar content_profile_name_img"
                         style="background-image: url(  https://100k.uz/themes/stock/assets/img/nouser.png)">
                        <input id="avatar" onchange="previewFile(this);" class="input-upload" type="file" name="avatar">
                    </div>

                    <div class="content_profile_name_text">
                        <p> Загрузить фото ! </p>
                        <label for="avatar">
                        <a href="#" onclick="return false" class="btn-new btn-input"> Загрузить фото </a>
                        </label>
                    </div>
                </div>
            </div>

            <div class="content_profile_form">
                <div class="form-group">
                    <label>Телефон</label>
                    <input type="text" readonly="" class="form-control"
                           placeholder=" Введите ваш номер телефона " value="<?php echo e($user_phone); ?>">
                </div>

                <div class="form-group">
                    <label>Имя</label>
                    <input type="text" name="first_name" class="form-control" placeholder=" Введите имя " value="">
                </div>

                <div class="form-group">
                    <label> Фамилия </label>
                    <input type="text" name="last_name" class="form-control" placeholder=" Введите фамилию " value="">
                </div>

                <div id="partialCountryState">

                    <div class="form-group">
                        <label for="accountCountry"> Регион </label>
                        <select class="region form-control">
                            <option>Select</option>
                            <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($region->id); ?>"><?php echo e($region->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="accountState"> Район / Город </label>
                        <select id="city_id" class="form-control" name="city_id">
                            <option value="" selected="selected"></option>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label> Ваш адрес </label>
                    <input type="text" name="address" class="form-control" placeholder="Введите ваш адрес" value="">
                </div>
                <button type="submit" class="btn-new btn-primary"> Отправить</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>

        function previewFile(input){
            var file = $("input[type=file]").get(0).files[0];

            if(file){
                var reader = new FileReader();

                reader.onload = function(){
                    $(".preview_avatar").css("background-image", "url('"+reader.result+"')");
                }

                reader.readAsDataURL(file);
            }
        }

        $(document).ready(function (){
            $(".region").change(function (){
                $.ajax({
                    'method': 'get',
                    'url': '<?php echo e(route("get_cities")); ?>',
                    data: {
                        'region_id' : this.value
                    },
                    success: function (data){
                        if (data.success)
                            innerCities(data.data)
                    },
                })
            })
        })

        function innerCities(cities){
            let str = ''
            for (let i=0;i<cities.length;i++) {
                str+='<option value="'+ cities[i].id +'">'
                str += cities[i].name
                str +='</option>'
            }
            $("#city_id").html(str)
        }

        var loadFile = function(event) {
            var reader = new FileReader();
            reader.onload = function(){
                $(".preview_avatar").css("background-image", reader.result)
            };
            reader.readAsDataURL(event.target.files[0]);
        };
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServer8\OpenServer\domains\100\100k\resources\views/auth/profile_items.blade.php ENDPATH**/ ?>