<?php $__env->startSection("content"); ?>

    <div class="container">
        <div class="content_linear_card">
            <div class="content_linear_card_header">
                <div class="content_linear_card_header_name">
                    <div class="content_linear_card_header_logo"><img src="<?php echo e(uImgUrl($product->user)); ?>" alt="clothes" /></div>
                    <div class="content_linear_card_header_info">
                        <p> <?php echo e($product->user->first_name); ?> </p>
                        <span> <a style="
                    font-weight: 500;
                    font-size: 14px;
                    color: #555;
                    text-decoration: underline;
                " href="#"><?php echo e($product->last_name); ?></a> </span>
                    </div>
                </div>

                <div class="content_linear_card_header_price">
                    <p> <?php echo e(price_format($product->price)); ?> </p>
                </div>
            </div>

            <div class="content_linear_card_body">
                <div class="owl-carousel owl-theme content_linear_card_body_indicators" style="display: flex!important;">

                    <div class="item" style="max-height: 800px">
                        <img loading="lazy" class="lazyload" src="<?php echo e(pImgUrl($product)); ?>" data-src="<?php echo e(pImgUrl($product)); ?>" alt="card" />
                    </div>
                   

                </div>
            </div>

            <div class="content_linear_card_info" style="border-bottom: none">
                <div class="content_linear_card_info_url">
                    <div class="d-flex">
                        <?php
                        if (auth()->check()) {
                        ?>

                        <a onclick="like(this, <?php echo e($product->id); ?>);return false" href="#"><span
                                class="icon-like <?php echo e(($product->liked) ? 'text-danger' : ''); ?>"></span>
                            <p> <?php echo e($product->like); ?> </p></a>

                        <?php } else { ?>
                        <a href="<?php echo e(route('login')); ?>"><span
                                class="icon-like <?php echo e(($product->liked) ? 'text-danger' : ''); ?>"></span>
                            <p> <?php echo e($product->like); ?> </p></a>
                        <?php } ?>
                    </div>

                    <a id="buyButton" onclick='fbq("track", "trackProductBasked"); FB.AppEvents.logEvent("productBasked")' class="text-danger"><span class="icon-basket"></span></a>

                    <a>
                        <span class="icon-bookmark "></span>
                    </a>

                </div>

                <hr style="margin: 0 -30px 20px">

                <div class="content_linear_card_info_text" style="font-size: 18px">
                   <?php echo $product->description; ?>

                </div>
            </div>
        </div>




        <div id="orderForm">
            <form id="orderForm" data-request-success="$(this).find('.needclear').val('')" data-request="onOrder" data-request-flash class="content_linear_card_buy">

                <h2 style="
                color: white;
                max-width: 80%;
                margin: auto;
                text-align: center;
                margin-bottom: 20px;
            "> Buyurtma berish </h2>

                <p class="text-center text-white"> Mahsulot narxi: <strong>277000 so'm</strong> </p>
                <p class="text-center text-white"> Mahsulot qoldi: <strong>1000 dona</strong> </p>

                <p class="text-center text-white"> Chegirma turi: 2 chi mahsulotdan boshlab <br> har bir mahsulot uchun <strong>30,000 so'm skidka</strong> </p>
                <br>


                <input type="hidden" name="product_id" value="434" />

                <div class="content_linear_card_buy_block">

                    <div>
                        <div class="form-group">
                            <label> Ismingiz </label>
                            <input class="form-control needclear" name="client_full_name" type="text"/>
                        </div>

                        <div class="form-group">
                            <label> Telefon raqamingiz </label>
                            <input class="my-phone-mask form-control needclear" name="client_phone" id="client_phone" placeholder="Telefon" type="text"/>
                        </div>


                        <div id="partialCountryState">

                            <div class="form-group">
                                <label for="accountCountry"> Viloyat </label>
                                <select id="accountCountry" class="form-control" name="country_id"><option value="13">Toshkent shahri</option><option value="12">Andijon</option><option value="11">Buxoro</option><option value="1">Fargona</option><option value="10">Jizzax</option><option value="6">Namangan</option><option value="7">Navoiy</option><option value="8">Qashqadaryo</option><option value="9">Qoraqalpogiston</option><option value="5">Samarqand</option><option value="3">Sirdaryo</option><option value="4">Surxondaryo</option><option value="2">Toshkent viloyati</option><option value="14">Xorazm</option></select>
                            </div>

                            <!-- emptyOption: '',
                                    'data-request': 'onInit',
                                    'data-request-update': {
                                        'country-state': '#partialCountryState'
                                    } -->

                            <!--
                            <div class="form-group">
                                <label for="accountState"> Tuman / Shahar </label>
                                <select id="accountState" class="form-control" emptyOption="" name="state_id"><option value="" selected="selected"></option></select>
                            </div> -->             </div>

                        <!-- <div class="form-group">
                           <label> Manzil yoki mo'ljal </label>
                           <input class="form-control" name="client_address" type="text"/>
                        </div> -->

                        <div class="form-group">
                            <label> Mahsulot soni </label>
                            <select name="quantity" class="form-control">
                                <option>1</option>
                                <option>2</option>
                                <option>3</option>
                                <option>4</option>
                                <option>5</option>
                            </select>
                        </div>

                        <button onclick='fbq("track", "trackNewOrder"); FB.AppEvents.logEvent("newOrder")' data-attach-loading type="submit" style="max-width: 100%" class="btn  btn-success"> Buyurtma berish </button>


                    </div>
                </div>
            </form>


        </div>




    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServer8\OpenServer\domains\100\100k\resources\views/product_single.blade.php ENDPATH**/ ?>