<?php $__env->startSection("content"); ?>
    <div class="container" id="productsList">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="content_linear">
                <div class="content_linear_card">
                    <div class="content_linear_card_header">
                        <div class="content_linear_card_header_name">
                            <div class="content_linear_card_header_logo"><img src="<?php echo e(uImgUrl($product->user)); ?>"
                                                                              alt="clothes"/></div>
                            <div class="content_linear_card_header_info">
                                <p> <?php echo e($product->user->first_name); ?> </p>
                                <span> <a style="
                    font-weight: 500;
                    font-size: 14px;
                    color: #555;
                    text-decoration: underline;
                " href="#"> <?php echo e($product->user->last_name); ?> </a> </span>
                            </div>
                        </div>

                        <div class="content_linear_card_header_price">
                            <p> <?php echo e(price_format($product->price)); ?> </p>
                        </div>
                    </div>

                    <a href="<?php echo e(pImgUrl($product)); ?>" class="content_linear_card_body">
                        <img loading="lazy" class="lazyload" src="<?php echo e(asset("assets/img/loading.gif")); ?>"
                             data-src="<?php echo e(pImgUrl($product)); ?>"
                             alt="card"/>
                    </a>

                    <div class="content_linear_card_info">
                        <div class="content_linear_card_info_url">
                            <div class="d-flex">
                                <?php
                                if (auth()->check()) {
                                    ?>

                                    <a onclick="like(this, <?php echo e($product->id); ?>);return false" href="#"><span
                                            class="icon-like <?php echo e(($product->liked) ? 'text-danger' : ''); ?>"></span>
                                        <p> <?php echo e($product->like); ?> </p></a>

                                <?php } else { ?>
                                    <a href="<?php echo e(route('login')); ?>"><span
                                            class="icon-like <?php echo e(($product->liked) ? 'text-danger' : ''); ?>"></span>
                                        <p> <?php echo e($product->like); ?> </p></a>
                                <?php } ?>

                            </div>

                            <a>
                                <span class="icon-bookmark "></span>
                            </a>

                        </div>

                        <div class="content_linear_card_info_text">
                            <p>
                            <p dir="ltr"><?php echo e($product->name); ?></p>

                            <p dir="ltr">
                                <a href="<?php echo e(url("product/" . $product->id)); ?>"> Batafsil </a>
                            </p>
                        </div>
                    </div>

                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div style="text-align: center; padding-bottom: 50px">
            <a href="https://play.google.com/store/apps/details?id=uz.itmaker.stock">
                <img src="storage/app/media/download-app.png" style="max-width: 100%">
            </a>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        function like(el, product_id) {

            $.ajax({
                method: 'post',
                url: '<?php echo e(route('like')); ?>',
                data: {
                    product_id: product_id,
                    '_token': $('meta[name="csrf-token"]').attr('content')
                },
                success: function (data) {
                    if (data.success) {
                        el.children[0].classList.add('text-danger')
                        el.children[1].innerHTML = data.data.like
                    }
                },
                error: function (err) {
                    console.log(err.responseText)
                }
            })
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OpenServer8\OpenServer\domains\100\100k\resources\views/welcome.blade.php ENDPATH**/ ?>