<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- Scripts -->


    <!-- Fonts -->


    <!-- Styles -->
    <link rel="shortcut icon" href="{{asset("assets/favicon/favicon.ico")}}" type="image/png">
    <link rel="stylesheet" href="{{asset("assets/owlcarousel/owl.carousel.min.css")}}"/>
    <link rel="stylesheet" href="{{asset("assets/owlcarousel/owl.theme.default.min.css")}}"/>
    <link rel="stylesheet" href="{{asset("assets/css/style.bundle.css")}}"/>
    <link rel="stylesheet" href="{{asset("assets/css/custom.css")}}"/>
    <link href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Berkshire+Swash&amp;display=swap" rel="stylesheet"/>
    <link href="https://fonts.googleapis.com/css?family=Raleway:400,400i,500,500i,600,600i,700,700i,800,800i"
          rel="stylesheet">

</head>
<body>
{{--    <div id="app">--}}
{{--        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">--}}
{{--            <div class="container">--}}
{{--                <a class="navbar-brand" href="{{ url('/') }}">--}}
{{--                    {{ config('app.name', 'Laravel') }}--}}
{{--                </a>--}}
{{--                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="{{ __('Toggle navigation') }}">--}}
{{--                    <span class="navbar-toggler-icon"></span>--}}
{{--                </button>--}}

{{--                <div class="collapse navbar-collapse" id="navbarSupportedContent">--}}
{{--                    <!-- Left Side Of Navbar -->--}}
{{--                    <ul class="navbar-nav mr-auto">--}}

{{--                    </ul>--}}

{{--                    <!-- Right Side Of Navbar -->--}}
{{--                    <ul class="navbar-nav ml-auto">--}}
{{--                        <!-- Authentication Links -->--}}
{{--                        @guest--}}
{{--                            @if (Route::has('login'))--}}
{{--                                <li class="nav-item">--}}
{{--                                    <a class="nav-link" href="{{ route('login') }}">{{ __('Login') }}</a>--}}
{{--                                </li>--}}
{{--                            @endif--}}

{{--                            @if (Route::has('register'))--}}
{{--                                <li class="nav-item">--}}
{{--                                    <a class="nav-link" href="{{ route('register') }}">{{ __('Register') }}</a>--}}
{{--                                </li>--}}
{{--                            @endif--}}
{{--                        @else--}}
{{--                            <li class="nav-item dropdown">--}}
{{--                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>--}}
{{--                                    {{ Auth::user()->name }}--}}
{{--                                </a>--}}

{{--                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">--}}
{{--                                    <a class="dropdown-item" href="{{ route('logout') }}"--}}
{{--                                       onclick="event.preventDefault();--}}
{{--                                                     document.getElementById('logout-form').submit();">--}}
{{--                                        {{ __('Logout') }}--}}
{{--                                    </a>--}}

{{--                                    <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">--}}
{{--                                        @csrf--}}
{{--                                    </form>--}}
{{--                                </div>--}}
{{--                            </li>--}}
{{--                        @endguest--}}
{{--                    </ul>--}}
{{--                </div>--}}
{{--            </div>--}}
{{--        </nav>--}}

{{--        <main class="py-4">--}}
{{--            @yield('content')--}}
{{--        </main>--}}
{{--    </div>--}}

<header class="header" id="top">
    <div class="container">
        <nav class="header_navbar">

            <a href="{{url('/')}}" class="header_navbar_brand_logo"> 100k.uz </a>


            <div class="header_navbar_collapse">
                <ul class="header_navbar_collapse_nav" style="min-height: 54px">
                    <li class="header_navbar_collapse_nav_item">
                        <div class="header_navbar_collapse_nav_item_pad">
                            <a class="header_navbar_collapse_nav_item_link active" href="index.html"
                            ><span class="icon-home"></span>
                                <p></p></a
                            >
                        </div>
                    </li>
                    <li class="header_navbar_collapse_nav_item">
                        <div class="header_navbar_collapse_nav_item_pad">
                            <a class="header_navbar_collapse_nav_item_link " href="explore.html"
                            > <span class="fa fa-search"></span>
                                <p></p></a
                            >
                        </div>
                    </li>

                    <li class="header_navbar_collapse_nav_item">
                        <div class="header_navbar_collapse_nav_item_pad">
                            <a class="header_navbar_collapse_nav_item_link " href="add.html"
                            > <span class="fa fa-plus"></span>
                                <p></p></a
                            >
                        </div>
                    </li>

                    <li class="header_navbar_collapse_nav_item">
                        <div class="header_navbar_collapse_nav_item_pad">
                            <a class="header_navbar_collapse_nav_item_link " href="shop/orders.html">
                                <span class="icon-cart"></span>
                                <p></p></a
                            >
                        </div>
                    </li>


                    <li class="header_navbar_collapse_nav_item">
                        <div class="header_navbar_collapse_nav_item_pad">
                            <a class="header_navbar_collapse_nav_item_link " href="auth.html">

                                <span class="icon-notifications"></span>

                                <p></p>
                            </a>
                        </div>
                    </li>
                </ul>
            </div>


            <div class="header_navbar_profile">
                <div class="d-flex align-items-center dropdown">
                    <a class="btn nav-link" data-toggle="dropdown" role="button" aria-haspopup="true"
                       aria-expanded="false">
                        <img src="{{asset("assets/img/nouser.png")}}" alt="profile"/>
                    </a>

                    <div class="dropdown-menu dropdown-menu-right header_navbar_lang_menu_dropdown">
                        <a class="dropdown-item header_navbar_lang_menu_dropdown_item" href="pages/contacts.html"> Aloqa
                            uchun </a>

                        @guest
                            @if (Route::has('login'))
                                <a class="dropdown-item header_navbar_lang_menu_dropdown_item" href="{{route('login')}}"> Profil </a>
                            @endif

                        @else
                            <a class="dropdown-item header_navbar_lang_menu_dropdown_item" href="{{url('home')}}"> Profil </a>
                        @endguest



                        <a class="d-none dropdown-item header_navbar_lang_menu_dropdown_item" href="auth.html"> Bonus
                            xarid qilish </a>

                        <a class="dropdown-item header_navbar_lang_menu_dropdown_item" href="auth.html"> Mening
                            sevimlilarim </a>
                        <a class="dropdown-item header_navbar_lang_menu_dropdown_item" href="auth.html"> Sozlamalar </a>

                        @if(auth()->check())
                            <form action="{{route('logout')}}" method="post">
                                @csrf
                                <input style="cursor: pointer;" class="dropdown-item header_navbar_lang_menu_dropdown_item" type="submit" value="Chiqish">
                            </form>
                        @endif

                        <hr class="my-2">

                        <a onclick='FB.AppEvents.logEvent("changeLanguageUz")'
                           class="bg-primary text-white dropdown-item header_navbar_lang_menu_dropdown_item"
                           data-request="onSwitchLocale" data-request-data="locale: 'uz'">
                            <img src="https://image.flaticon.com/icons/svg/206/206662.svg"
                                 style="width: 24px; margin-right: 10px;" alt="">
                            O'zbekcha
                        </a>

                        <a onclick='FB.AppEvents.logEvent("changeLanguageRu")'
                           class=" dropdown-item header_navbar_lang_menu_dropdown_item" data-request="onSwitchLocale"
                           data-request-data="locale: 'ru'">
                            <img src="https://image.flaticon.com/icons/svg/555/555451.svg"
                                 style="width: 24px; margin-right: 10px;" alt="">
                            Русский
                        </a>

                        <hr class="my-2">

                        <div class="d-flex justify-content-between px-2">
                            <!-- <a onclick='FB.AppEvents.logEvent("openTg")' href="https://t.me/offical_100k" class="p-2">
                                <img src="https://image.flaticon.com/icons/svg/2111/2111646.svg" style="width: 20px;" alt="">
                            </a> -->

                            <a onclick='FB.AppEvents.logEvent("openAndroid")' target="_blank"
                               href="https://play.google.com/store/apps/details?id=uz.itmaker.stock" class="p-2">
                                <img src="https://image.flaticon.com/icons/svg/732/732179.svg" style="width: 20px;"
                                     alt="">
                            </a>

                            <a onclick='FB.AppEvents.logEvent("openIos")' target="_blank"
                               href="https://apps.apple.com/ru/app/100k-uz/id1529911106" class="p-2">
                                <img src="https://image.flaticon.com/icons/svg/831/831276.svg" style="width: 20px;"
                                     alt="">
                            </a>
                        </div>

                    </div>
                </div>
            </div>

        </nav>
    </div>

    <style>
        .header_navbar_collapse_nav_item_link {
            border: none;
        }

        .header_navbar_collapse_nav_item_link span {
            font-size: 20px;
        }
    </style>
</header>

<main>
    <section class="main">
        @yield("content")
    </section>


    <style>
        .container {
            background: transparent;
        }

        .content_linear {
            max-width: 600px;
            padding-top: 20px;
            margin: auto;
        }

        .content_linear .content_linear_card {
            background: #fff;
            margin-bottom: 40px;
            border: 1px solid #ddd;
        }
    </style>
</main>

<script src="{{asset("assets/jquery-3.3.1.min.js")}}"></script>
<script src="../kit.fontawesome.com/43236b6dfa.js" crossorigin="anonymous"></script>
<script src="https://unpkg.com/imask"></script>


<script src="{{asset("assets/js/bundle.js")}}"></script>
<script src="{{asset("assets/lazysizes/lazysizes.min.js")}}"></script>
<script src="{{asset("assets/owlcarousel/owl.carousel.min.js")}}"></script>
{{--    <script src="../rawgit.com/RobinHerbots/jquery.inputmask/3.x/dist/jquery.inputmask.bundle.js"></script>--}}
<script src="{{asset("assets/js/custom.js")}}"></script>
<script src="{{asset("assets/js/framework.js")}}"></script>
<script src="{{asset("assets/js/framework.extras.js")}}"></script>
<link rel="stylesheet" property="stylesheet" href="{{asset("assets/css/framework.extras.css")}}">
@yield("scripts")


</body>
</html>
