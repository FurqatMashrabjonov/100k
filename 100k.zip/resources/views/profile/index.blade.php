@extends("layouts.app")

@section("content")


    <h1>Profile</h1>


@endsection
