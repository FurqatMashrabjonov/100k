@extends('layouts.app')

@section('content')


    <div class="container">
        <br>
        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form method="post" action="{{url()->current()}}" enctype="multipart/form-data" class="content_profile">
            @csrf
            <div class="content_profile_main">
                <div class="content_profile_name">
                    <div class="preview_avatar content_profile_name_img"
                         style="background-image: url(  https://100k.uz/themes/stock/assets/img/nouser.png)">
                        <input id="avatar" onchange="previewFile(this);" class="input-upload" type="file" name="avatar">
                    </div>

                    <div class="content_profile_name_text">
                        <p> Загрузить фото ! </p>
                        <label for="avatar">
                        <a href="#" onclick="return false" class="btn-new btn-input"> Загрузить фото </a>
                        </label>
                    </div>
                </div>
            </div>

            <div class="content_profile_form">
                <div class="form-group">
                    <label>Телефон</label>
                    <input type="text" readonly="" class="form-control"
                           placeholder=" Введите ваш номер телефона " value="{{$user_phone}}">
                </div>

                <div class="form-group">
                    <label>Имя</label>
                    <input type="text" name="first_name" class="form-control" placeholder=" Введите имя " value="">
                </div>

                <div class="form-group">
                    <label> Фамилия </label>
                    <input type="text" name="last_name" class="form-control" placeholder=" Введите фамилию " value="">
                </div>

                <div id="partialCountryState">

                    <div class="form-group">
                        <label for="accountCountry"> Регион </label>
                        <select class="region form-control">
                            <option>Select</option>
                            @foreach($regions as $region)
                                <option value="{{$region->id}}">{{$region->name}}</option>
                            @endforeach
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="accountState"> Район / Город </label>
                        <select id="city_id" class="form-control" name="city_id">
                            <option value="" selected="selected"></option>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label> Ваш адрес </label>
                    <input type="text" name="address" class="form-control" placeholder="Введите ваш адрес" value="">
                </div>
                <button type="submit" class="btn-new btn-primary"> Отправить</button>
            </div>
        </form>
    </div>
@endsection
@section('scripts')
    <script>

        function previewFile(input){
            var file = $("input[type=file]").get(0).files[0];

            if(file){
                var reader = new FileReader();

                reader.onload = function(){
                    $(".preview_avatar").css("background-image", "url('"+reader.result+"')");
                }

                reader.readAsDataURL(file);
            }
        }

        $(document).ready(function (){
            $(".region").change(function (){
                $.ajax({
                    'method': 'get',
                    'url': '{{route("get_cities")}}',
                    data: {
                        'region_id' : this.value
                    },
                    success: function (data){
                        if (data.success)
                            innerCities(data.data)
                    },
                })
            })
        })

        function innerCities(cities){
            let str = ''
            for (let i=0;i<cities.length;i++) {
                str+='<option value="'+ cities[i].id +'">'
                str += cities[i].name
                str +='</option>'
            }
            $("#city_id").html(str)
        }

        var loadFile = function(event) {
            var reader = new FileReader();
            reader.onload = function(){
                $(".preview_avatar").css("background-image", reader.result)
            };
            reader.readAsDataURL(event.target.files[0]);
        };
    </script>
@endsection
