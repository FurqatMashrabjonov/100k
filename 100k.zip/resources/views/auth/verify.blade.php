@extends('layouts.app')

@section('content')
    <div class="content_auth" style="background-image: url( {{asset("assets/img/back-blur.jpg")}})">




        <div class="content_auth_block">
            <div id="authContainer">


                <form action="{{route("verify")}}" method="post" class="content_auth_form">


                    @if(isset($token_error))
                        <span class="alert alert-danger">{{$token_error}}</span>
                    @endif


                    @csrf
                    <a href="{{url('/')}}" class="header_navbar_brand_logo">100k.uz </a>
                    <label class="content_auth_form_group">
                        <span>Verify </span>

                        <div class="content_auth_form_group_input">
                            <input
                                name="phone_token"
                                type="text"
                                class="form-control my-phone-mask"
                                id="phone_token"
                                placeholder="Kodni kiriting"
                            />

                            <button type="submit" class="btn">
                                <i class="far fa-arrow-alt-circle-right"></i>
                            </button>
                        </div>
                    </label>
                        <a href="{{url("verify")}}">Qayta Yuborish</a>
                </form>
            </div>
        </div>

    </div>


@endsection
